import { Link } from "react-router-dom"
import List from "./List2"

export default function Board() {
  return (
    <div>
      <br />
      <List2 />
    </div>
  )
}
